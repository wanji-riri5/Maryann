package com.example.smartnotes.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import com.example.smartnotes.models.Note;
import com.example.smartnotes.models.User;

@Database(entities = {Note.class, User.class}, version = 3)  // version increased
@TypeConverters({Converters.class})
public abstract class NoteDatabase extends RoomDatabase {

    private static NoteDatabase instance;

    public abstract NoteDao noteDao();
    public abstract UserDao userDao();  // new Dao

    public static synchronized NoteDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            NoteDatabase.class, "note_database")
                    .fallbackToDestructiveMigration()  // easiest for development
                    .build();
        }
        return instance;
    }
}

