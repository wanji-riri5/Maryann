package com.example.smartnotes.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartnotes.R;
import com.example.smartnotes.adapters.NoteAdapter;
import com.example.smartnotes.database.NoteDatabase;
import com.example.smartnotes.models.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnNoteClickListener {

    private RecyclerView recyclerView;
    private NoteAdapter adapter;
    private NoteDatabase noteDatabase;
    private List<Note> noteList = new ArrayList<>();
    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if user is logged in (using SharedPreferences)
        SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        if (!sharedPreferences.getBoolean("isLoggedIn", false)) {
            // Not logged in – redirect to LoginActivity
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // Set up toolbar with two-tone app name
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        TextView appName = findViewById(R.id.appName);
        setTwoToneAppName(appName);

        // Initialize views
        searchEditText = findViewById(R.id.searchEditText);
        recyclerView = findViewById(R.id.recyclerView);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);

        // Get database instance
        noteDatabase = NoteDatabase.getInstance(this);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(noteList, this);
        recyclerView.setAdapter(adapter);

        // FAB click listener to open note editor
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NoteEditActivity.class);
            startActivity(intent);
        });

        // Search functionality
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Load notes from database
        loadNotes();
    }

    private void setTwoToneAppName(TextView textView) {
        String text = "Smart Notes";
        SpannableString spannable = new SpannableString(text);
        spannable.setSpan(new ForegroundColorSpan(Color.WHITE), 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // "Smart"
        spannable.setSpan(new ForegroundColorSpan(0xFFBBDEFB), 6, 11, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // "Notes"
        textView.setText(spannable);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes(); // Refresh list when returning to this screen
    }

    private void loadNotes() {
        new Thread(() -> {
            List<Note> notes = noteDatabase.noteDao().getAllNotes();
            runOnUiThread(() -> {
                noteList.clear();
                noteList.addAll(notes);
                adapter.updateNotes(noteList);
            });
        }).start();
    }

    private void filterNotes(String query) {
        new Thread(() -> {
            List<Note> allNotes = noteDatabase.noteDao().getAllNotes();
            List<Note> filtered = new ArrayList<>();
            if (query.isEmpty()) {
                filtered.addAll(allNotes);
            } else {
                for (Note note : allNotes) {
                    if (note.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                            note.getContent().toLowerCase().contains(query.toLowerCase())) {
                        filtered.add(note);
                    }
                }
            }
            List<Note> finalFiltered = filtered;
            runOnUiThread(() -> adapter.updateNotes(finalFiltered));
        }).start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            // Clear login state and go back to LoginActivity
            SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
            sharedPreferences.edit().clear().apply();

            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onNoteClick(Note note) {
        Intent intent = new Intent(this, NoteEditActivity.class);
        intent.putExtra("note", note);
        startActivity(intent);
    }

    @Override
    public void onNoteLongClick(Note note) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Note")
                .setMessage("Are you sure you want to delete this note?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    new Thread(() -> {
                        noteDatabase.noteDao().delete(note);
                        runOnUiThread(this::loadNotes);
                    }).start();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}