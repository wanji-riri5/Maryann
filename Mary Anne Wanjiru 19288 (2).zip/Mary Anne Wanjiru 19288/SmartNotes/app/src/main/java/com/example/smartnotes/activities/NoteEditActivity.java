package com.example.smartnotes.activities;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.smartnotes.R;
import com.example.smartnotes.database.NoteDatabase;
import com.example.smartnotes.models.Note;
import java.util.Date;

public class NoteEditActivity extends AppCompatActivity {

    private EditText etTitle, etContent;
    private NoteDatabase noteDatabase;
    private Note currentNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_edit);

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize views
        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);

        // Get database instance
        noteDatabase = NoteDatabase.getInstance(this);

        // Check if we're editing an existing note
        if (getIntent().hasExtra("note")) {
            currentNote = (Note) getIntent().getSerializableExtra("note");
            etTitle.setText(currentNote.getTitle());
            etContent.setText(currentNote.getContent());
            setTitle("Edit Note");
        } else {
            setTitle("New Note");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu with the Save button
        getMenuInflater().inflate(R.menu.menu_note_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_save) {
            saveNote();
            return true;
        } else if (id == android.R.id.home) {
            finish(); // Go back without saving
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void saveNote() {
        String title = etTitle.getText().toString().trim();
        String content = etContent.getText().toString().trim();

        // Validate title (required)
        if (title.isEmpty()) {
            Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save in background thread
        new Thread(() -> {
            if (currentNote == null) {
                // Create new note
                Note note = new Note(title, content);
                noteDatabase.noteDao().insert(note);
            } else {
                // Update existing note
                currentNote.setTitle(title);
                currentNote.setContent(content);
                currentNote.setUpdatedAt(new Date());
                noteDatabase.noteDao().update(currentNote);
            }

            // Return to previous screen on UI thread
            runOnUiThread(() -> {
                Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
                finish();
            });
        }).start();
    }
}
